<!DOCTYPE html>
<html lang="es">

<head>
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        input[type="number"] {
            width: 50px;
        }

        body {
            background-image: url('img/terminal.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }

        .tm-section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .tm-bg-img {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            width: 80%;
        }

        .tm-section h2 {
            width: 100%;
            text-align: center;
            margin: 10px 0;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php
    session_start();
    include "cabecera_admin.php";


    $dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
    $dbuser = "root";
    $dbpass = "root123456789";
    $db = "VUELOS";

    $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);
    if ($mysqli->connect_errno) {
        die("La conexión a la base de datos falló: " . $mysqli->connect_error);
    }

    $whereClauses = [];
    $params = [];
    $types = "";

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (!empty($_POST['id']) && $_POST['id'] != 0) {
            $whereClauses[] = "id = ?";
            $params[] = $_POST['id'];
            $types .= "i";
        }

        if (!empty($_POST['nombre'])) {
            $whereClauses[] = "nombre LIKE ?";
            $params[] = "%" . $_POST['nombre'] . "%";
            $types .= "s";
        }

        if (!empty($_POST['apellidos'])) {
            $whereClauses[] = "apellidos LIKE ?";
            $params[] = "%" . $_POST['apellidos'] . "%";
            $types .= "s";
        }

        if (!empty($_POST['usuario'])) {
            $whereClauses[] = "usuario LIKE ?";
            $params[] = "%" . $_POST['usuario'] . "%";
            $types .= "s";
        }

        if (!empty($_POST['admin'])) {
            $whereClauses[] = "admin = ?";
            $params[] = $_POST['admin'];
            $types .= "s";
        }
    }

    $query = "SELECT * FROM usuarios";
    if (!empty($whereClauses)) {
        $query .= " WHERE " . implode(" AND ", $whereClauses);
    }

    $stmt = $mysqli->prepare($query);
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $mysqli->error);
    }

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <div class="tm-section">
        <div class="tm-bg-img">
            <div style="width: 45%;">
                <h2>Gestión de Usuarios</h2>
                <hr>
                <form action="gestion_usuarios.php" method="post">
                    <p>Busca por:</p>
                    <p>
                        ID: <input type="number" min="0" value="0" name="id" size="5" style="margin-right: 8px;">
                        Nombre: <input type="text" name="nombre" size="5" style="margin-right: 8px;">
                        Apellidos: <input type="text" name="apellidos" size="5" style="margin-right: 8px;">
                        Usuario: <input type="text" name="usuario" size="5" style="margin-right: 8px;">
                        Administrador: <input type="text" name="admin" size="5" style="margin-right: 8px;">
                        <input type="submit" value="Buscar">
                    </p>
                    <?php
                    if (isset($_GET['errorfiltro']) && $_GET['errorfiltro'] == true) {
                        echo "<p style='color: red;'>Rellene al menos un campo</p>";
                    }
                    ?>
                </form>

                <?php if (!empty($result) && $result->num_rows > 0) : ?>
                    <table class="table" style="text-align: center;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Apellidos</th>
                                <th>Usuario</th>
                                <th>Permisos Administración</th>
                                <th>Editar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($fila = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $fila['id'] . "</td>";
                                echo "<td>" . $fila['nombre'] . "</td>";
                                echo "<td>" . $fila['apellidos'] . "</td>";
                                echo "<td>" . $fila['usuario'] . "</td>";
                                echo "<td>" . $fila['admin'] . "</td>";
                                echo "<td><a href='gestion_usuario_individual.php?id=" . $fila['id'] . "'>Editar</a></td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p>No existen usuarios.</p>
                <?php endif; ?>

                <?php
                $stmt->close();
                $mysqli->close();
                ?>
            </div>
        </div>
    </div>
</body>


</html>
