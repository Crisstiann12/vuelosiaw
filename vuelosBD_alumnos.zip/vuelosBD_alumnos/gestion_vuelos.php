<!DOCTYPE html>
<html lang="es">

<head>
    <title>Gestión de Vuelos</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        input[type="number"] {
            width: 50px;
        }

        body {
            background-image: url('img/terminal.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }

        .tm-section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .tm-bg-img {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            width: 80%;
        }

        .tm-section h2 {
            width: 100%;
            text-align: center;
            margin: 10px 0;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php
    session_start();
    include "cabecera.php";

    if (!$_SESSION['admin']) {
        header("Location: index.php");
        exit();
    }

    $dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
    $dbuser = "root";
    $dbpass = "root123456789";
    $db = "VUELOS";

    $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);
    if ($mysqli->connect_errno) {
        die("La conexión a la base de datos falló: " . $mysqli->connect_error);
    }

    $whereClauses = [];
    $params = [];
    $types = "";

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (!empty($_POST['id']) && $_POST['id'] != 0) {
            $whereClauses[] = "id = ?";
            $params[] = $_POST['id'];
            $types .= "i";
        }

        if (!empty($_POST['codigo_aeropuerto_origen'])) {
            $whereClauses[] = "codigo_aeropuerto_origen LIKE ?";
            $params[] = "%" . $_POST['codigo_aeropuerto_origen'] . "%";
            $types .= "s";
        }

        if (!empty($_POST['codigo_aeropuerto_destino'])) {
            $whereClauses[] = "codigo_aeropuerto_destino LIKE ?";
            $params[] = "%" . $_POST['codigo_aeropuerto_destino'] . "%";
            $types .= "s";
        }

        if (!empty($_POST['fecha_salida'])) {
            $whereClauses[] = "fecha_salida = ?";
            $params[] = $_POST['fecha_salida'];
            $types .= "s";
        }

        if (!empty($_POST['fecha_llegada'])) {
            $whereClauses[] = "fecha_llegada = ?";
            $params[] = $_POST['fecha_llegada'];
            $types .= "s";
        }

        if (!empty($_POST['precio']) && $_POST['precio'] != 0) {
            $whereClauses[] = "precio = ?";
            $params[] = $_POST['precio'];
            $types .= "d";
        }
    }

    $query = "SELECT * FROM vuelos";
    if (!empty($whereClauses)) {
        $query .= " WHERE " . implode(" AND ", $whereClauses);
    }

    $stmt = $mysqli->prepare($query);
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $mysqli->error);
    }

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <div class="tm-section">
        <div class="tm-bg-img">
            <div style="width: 45%;">
                <h2>Gestión de Vuelos</h2>
                <hr>
                <form action="gestion_vuelos.php" method="post">
                    <p>Busca por:</p>
                    <p>
                        ID: <input type="number" min="0" value="0" name="id" size="5" style="margin-right: 8px;">
                        Origen: <input type="text" name="codigo_aeropuerto_origen" size="5" style="margin-right: 8px;">
                        Destino: <input type="text" name="codigo_aeropuerto_destino" size="5" style="margin-right: 8px;">
                        Fecha Salida: <input type="date" name="fecha_salida" size="5" style="margin-right: 8px;">
                        Fecha Llegada: <input type="date" name="fecha_llegada" size="5" style="margin-right: 8px;">
                        Precio: <input type="number" step="0.01" min="0" value="0" name="precio" size="5" style="margin-right: 8px;">
                        <input type="submit" value="Buscar">
                    </p>
                    <?php
                    if (isset($_GET['errorfiltro']) && $_GET['errorfiltro'] == true) {
                        echo "<p style='color: red;'>Rellene al menos un campo</p>";
                    }
                    ?>
                </form>

                <?php if (!empty($result) && $result->num_rows > 0) : ?>
                    <table class="table" style="text-align: center;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Origen</th>
                                <th>Destino</th>
                                <th>Fecha Salida</th>
                                <th>Hora Salida</th>
                                <th>Fecha Llegada</th>
                                <th>Hora Llegada</th>
                                <th>Plazas Libres</th>
                                <th>Precio</th>
                                <th>Editar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($fila = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $fila['id'] . "</td>";
                                echo "<td>" . $fila['codigo_aeropuerto_origen'] . "</td>";
                                echo "<td>" . $fila['codigo_aeropuerto_destino'] . "</td>";
                                echo "<td>" . $fila['fecha_salida'] . "</td>";
                                echo "<td>" . $fila['hora_salida'] . "</td>";
                                echo "<td>" . $fila['fecha_llegada'] . "</td>";
                                echo "<td>" . $fila['hora_llegada'] . "</td>";
                                echo "<td>" . $fila['plazas_libres'] . "</td>";
                                echo "<td>" . $fila['precio'] . "</td>";
                                echo "<td><a href='gestion_vuelo_individual.php?id=" . $fila['id'] . "'>Editar</a></td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p>No existen vuelos.</p>
                <?php endif; ?>

                <?php
                $stmt->close();
                $mysqli->close();
                ?>
            </div>
        </div>
    </div>
</body>

</html>
