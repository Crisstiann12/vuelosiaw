<!DOCTYPE html>
<?php
session_start();

//PARA QUE NINGUN USR PUEDA ACCEDER A LA PÁGINA (ESTABLECER LA CABECERA SOLO A PAGINAS ADMIN)

if (!isset($_SESSION['admin'])) {
    
    header('Location: index.php');

}

$isAdmin = isset($_SESSION['admin']) && $_SESSION['admin'];

?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>TFG Nicole y Cristian</title>

    <!-- load stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700"> <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css"> <!-- Font Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css"> <!-- Bootstrap style -->
    <link rel="stylesheet" type="text/css" href="slick/slick.css" />
    <link rel="stylesheet" type="text/css" href="slick/slick-theme.css" />
    <link rel="stylesheet" type="text/css" href="css/datepicker.css" />
    <link rel="stylesheet" href="css/tooplate-style.css"> <!-- Templatemo style -->



    <style>
        .web-logo {
            height: 80px;
        }

        .tm-top-bar {
            /*position: fixed;*/
            top: 0;
            left: 0;
            width: 100%;
            padding: 0;
            z-index: 10000;
            transition: all 0.2s ease-in-out;
            height: 100px;
            background: white;
        }

        #tm-section-1 {
            background-image: url(img/terminal.jpg);
        }
    </style>

</head>

<body>
    <div class="tm-main-content" id="top">
        <!--      <div class="tm-top-bar-bg">
  Top Navbar 
        </div>-->
        <div class="tm-top-bar" id="tm-top-bar">

            <div class="container">
                <div class="row">

                    <nav class="navbar navbar-expand-lg narbar-light">
                        <a class="navbar-brand mr-auto" href="#">
                            <img src="img/IAWAirlines.png" class="web-logo" alt="Site logo">

                        </a>
                        <button type="button" id="nav-toggle" class="navbar-toggler collapsed" data-toggle="collapse" data-target="#mainNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div id="mainNav" class="collapse navbar-collapse">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Indice<span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="listarCompras.php">Tus Compras</a>
                                </li>

                                <?php

                                if ($isAdmin) {

                                    print "<li class='nav-item'>";
                                    print "<a class='nav-link' href='administracion.php'>Administración</a></li>";

                                }

                                
                                if (!isset($_SESSION['logueado'])) {

                                    print ' <li class="nav-item">
                                                <a class="nav-link" href="registro.php">Registrate</a>
                                            </li>';
                                }

                                if (isset($_SESSION['logueado']) && ($_SESSION['logueado']) == true) {

                                    print ' <li class="nav-item">
                                                <a class="nav-link" href="procesar_logout.php"> Cerrar Sesión</a>
                                            </li>';

                                } else {

                                    print ' <li class="nav-item">
                                                <a class="nav-link" href="login.php">Iniciar Sesión</a>
                                            </li>';
                                }

                                if (isset($_SESSION['logueado']) && ($_SESSION['logueado']) == true) {
                                    print '<li class="nav-item">
                                    <a class="nav-link">' . $_SESSION["usuario"] . '</a>
                                    </li>';
                                }
        
                                ?>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>