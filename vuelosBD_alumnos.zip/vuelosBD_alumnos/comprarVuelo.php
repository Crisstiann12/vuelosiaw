<?php include "cabecera.php";

if (isset($_SESSION['logueado']) && ($_SESSION['logueado']) == true) {
    $concadenarvalores = $_POST['selecciona'];

    $filavalores = explode(',', $concadenarvalores);

    $_SESSION['id'] = $filavalores[0];
    $_SESSION['ciudad_origen'] = $filavalores[2];
    $_SESSION['ciudad_destino'] = $filavalores[4];
    $_SESSION['plazas_libres'] = $filavalores[9];
    $_SESSION['fecha_salida'] = $filavalores[5];
    $_SESSION['fecha_llegada'] = $filavalores[7];
    $_SESSION['precio'] = $filavalores[10];
    /*
    echo $_SESSION['id'];
    echo "<br>";
    echo $_SESSION['ciudad_origen'];
    echo "<br>";
    echo $_SESSION['ciudad_destino'];echo "<br>";
    echo $_SESSION['plazas_libres'];echo "<br>";
    echo $_SESSION['fecha_salida'];echo "<br>";
    echo $_SESSION['fecha_llegada'];echo "<br>";
    echo $_SESSION['precio'];echo "<br>";
    */
} else {
    header('Location: login.php?error=iniciosession');
}

?>

<div class="tm-section tm-bg-img" id="tm-section-1">
    <div class="tm-bg-white ie-container-width-fix-2">
        <div class="container ie-h-align-center-fix">
            <div class="row">
                <div class="col-xs-12 ml-auto mr-auto ie-container-width-fix">

                    <h2 style="text-align:center;">Datos de compra</h2>
                    <form action="mostrarDatos.php" method="post" class="tm-search-form tm-section-pad-2" id="formPagar">



                        <div class="form-group">
                            <label class="col-form-label" for="politica-cancelacion">Politica de cancelación:</label>

                            <select class="form-control" style="height:50px;" id="politica-cancelacion" name="politica-cancelacion">
                                <option selected="">Selecciona una tarifa</option>
                                <option value="sin-cancelacion">Sin Cancelación</option>
                                <option value="cancelacion-partial">Cancelación con Devolución Parcial (+60€ ppers)</option>
                                <option value="reembolsable">Totalmente Reembolsable (+120€ ppers)</option>
                            </select>

                        </div>

                        <div class="form-group">
                            <label class="col-form-label" for="inputNombre">Nombre</label>
                            <input type="text" name="nombreUsuario" style="width: 500px;" class="form-control" placeholder="Nombre" id="inputNombre">
                        </div>


                        <div class="form-group">
                            <label class="col-form-label" for="inputApellidos">Apellidos</label>
                            <input type="text" name="apellidoUsuario" class="form-control" placeholder="Apellidos" id="inputApellidos">
                        </div>

                        <div class="form-group">
                            <label class="col-form-label" for="inputTarjetaDeCredito">Tarjeta de credito</label>
                            <input type="text" name="tarjetaUsuario" class="form-control" placeholder="Tarjeta de credito" id="inputTarjetaDeCredito">
                            <?php

                            if (isset($_GET['error']) && $_GET['error'] == true) {

                                echo "<p style='color: red;'>Selecciona todas las opciones</p>";
                            }

                            ?>
                        </div>

                        <button type="submit" class="btn btn-primary tm-btn-search"> Pagar</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>




</body>

</html>