<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "root";
$db = "CRUD";

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);

if ($mysqli->connect_errno) {
    die("La conexión a la base de datos falló: " . $mysqli->connect_error);
}

?>