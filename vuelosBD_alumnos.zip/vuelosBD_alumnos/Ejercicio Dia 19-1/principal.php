<!DOCTYPE html>
<html lang="es">

<head>
    <title>CRUD CALIFICACIONES</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        h3.textlogin {
            text-align: center;
            font-size: 30px;
        }

        form.form {
            width: 600px;
            padding: 50px;
            border-radius: 10px;
            margin: auto;
            margin-top: 150px;
            padding-top: 20px;
            border-style: solid;
            border-color: black;
        }

        form input {
            margin-left: 20px;
            background-color: dark;
            border-style: double;
            border-color: black;
            color: black;
            outline: none;
            /* Para que no se vea el borde al darle click en la casilla */
        }

        body {
            background-color: antiquewhite;
        }

        h3.textlogin {
            text-align: center;
            font-size: 30px;
        }

        .contenedor-tabla {
            margin: 20px;
        }

        table {
            margin: auto;
            border-collapse: collapse;
            width: 80%;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 10px;
        }
    </style>


</head>

<body>
    <div style="text-align: center;">
        <form action="procesar_datos.php" method="post">
            <p style="text-decoration-line: underline; font-size:30px;">CRUD DE CALIFICACIONES</p>

            <p>ID Calificacion:<input type="number" name="id_calificacion" size="15" style="margin-right: 30px;"></p>

            <p>ID Estudiante:<input type="number" name="id_estudiante" size="15" style="margin-right: 30px;">
                ID Curso:<input type="number" name="id_curso" size="15" style="margin-right: 30px;">
                Calificación:<input type="text" name="calificacion" size="20" style="margin-right: 40px;">
                Fecha:<input type="date" name="fecha" size="20" style="margin-right: 40px;">

            <p>Selecciona la función a realizar:<select name="Validar" style="margin-left: 10px;">
                    <option value="Selecciona">--Selecciona--</option>
                    <option value="Añadir">Añadir</option>
                    <option value="Modificar">Modificar</option>
                    <option value="Borrar">Borrar</option>
                </select>
            </p>
            <p>Campo a modificar:<select name="modificar" style="margin-left: 10px;">
                    <option value="Selecciona">--Selecciona--</option>
                    <option value="id_estudiante">id_estudiante</option>
                    <option value="id_curso">id_curso</option>
                    <option value="valor_calificacion">valor_calificacion</option>
                    <option value="fecha_calificacion">fecha_calificacion</option>
                </select>
            </p>
            <?php

            if (isset($_GET['error']) && $_GET['error'] == true) {
                echo "<p style='color: red;'>Error al actualizar la Base de Datos</p>";
            }
            ?>
            <input type="submit" value="Procesar Datos">
        </form>

    </div>
    <br>
    <?php

    include 'conexionBD.php';

    echo "<div class='contenedor-tabla'>";
    echo "<table>";
    echo "<tr><th>ID Estudiante</th>
    <th>Nombre</th>
    <th>Apellido</th>
    <th>Fecha Nacimiento</th>
    <th>Email</th></tr>";

    $stmt = $mysqli->query("SELECT * FROM estudiante;");

    if ($stmt) {
        while ($fila = $stmt->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $fila['id_estudiante'] . "</td>
            <td>" . $fila['nombre'] . "</td>
            <td>" . $fila['apellido'] . "</td>
            <td>" . $fila['fecha_nacimiento'] . "</td>
            <td>" . $fila['email'] . "</td>";
            echo "</tr>";
        }
        $stmt->close();
    } else {
        echo "Error en la consulta: " . $mysqli->error;
    }

    echo "</table>";
    echo "</div>";

    echo "<br><br>";

    echo "<div class='contenedor-tabla'>";
    echo "<table>";
    echo "<tr><th>ID Calificacion</th>
    <th>ID Estudiante</th>
    <th>Nombre</th>
    <th>Apellidos</th>
    <th>ID Curso</th>
    <th>Valor Calificacion</th>
    <th>Fecha Calificacion</th>
    </tr>";

    $stmt = $mysqli->query("SELECT calificacion.*,
                estudiante.nombre,
                estudiante.apellido
                FROM calificacion
                JOIN estudiante ON calificacion.id_estudiante = estudiante.id_estudiante;
    ");

    if ($stmt) {
        while ($fila = $stmt->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $fila['id_calificacion'] . "</td>
            <td>" . $fila['id_estudiante'] . "</td>
            <td>" . $fila['nombre'] . "</td>
            <td>" . $fila['apellido'] . "</td>
            <td>" . $fila['id_curso'] . "</td>
            <td>" . $fila['valor_calificacion'] . "</td>
            <td>" . $fila['fecha_calificacion'] . "</td>";
            
            echo "</tr>";
        }
        $stmt->close();
    } else {
        echo "Error en la consulta: " . $mysqli->error;
    }

    echo "</table>";
    echo "</div>";

    $mysqli->close();
    ?>

</body>

</html>