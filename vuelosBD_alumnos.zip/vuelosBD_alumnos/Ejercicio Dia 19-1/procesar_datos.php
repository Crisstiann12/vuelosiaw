<?php

include 'conexionBD.php';

if (isset($_POST['Validar']) && $_POST['Validar'] !== '--Selecciona--') {
    $funcion = $_POST['Validar'];

    $id_calificacion = $_POST['id_calificacion'];
    $id_curso = $_POST['id_curso'];
    $id_estudiante = $_POST['id_estudiante'];

    $calificacion = $_POST['calificacion'];
    $fecha = $_POST['fecha'];

    $modificar = $_POST['modificar'];

    //ESTE APARTADO DE FECHA NO FUNCIONABA, CON LA IA HE PEDIDO QUE CORRIGA EL CODIGO Y ME
    //DIÓ ESTA VARIABLE, LA INSERTÉ Y FUNCIONA PERO SIN ENTENDER PORQUÉ **PREGUNTAR**

    // Supongamos que el formato de $_POST['fecha'] es solo el año ('2004')
    // Puedes agregar el mes y el día para formar una fecha completa

    $fecha_completa = $fecha . '-01-01';

    switch ($funcion) {
        case 'Añadir':

            $stmt = "INSERT INTO calificacion (id_estudiante,id_curso,valor_calificacion,fecha_calificacion) 
                    VALUES ($id_estudiante,$id_curso, $calificacion, '$fecha_completa');";
            $resultado = mysqli_query($mysqli, $stmt);
            break;

        case 'Modificar':

            switch ($modificar) {
                case 'id_estudiante':

                    $stmt2 = "UPDATE calificacion
                    SET id_estudiante=$id_estudiante WHERE id_calificacion=$id_calificacion";
                    $resultado3 = mysqli_query($mysqli, $stmt2);
                    break;
                    
                case 'id_curso':

                    $stmt3 = "UPDATE calificacion
                    SET id_curso=$id_curso WHERE id_calificacion=$id_calificacion";
                    $resultado3 = mysqli_query($mysqli, $stmt3);
                    break;

                case 'valor_calificacion':
 
                    $stmt4 = "UPDATE calificacion
                    SET valor_calificacion=$calificacion WHERE id_calificacion=$id_calificacion";
                    $resultado4 = mysqli_query($mysqli, $stmt4);
                    break;

                case 'fecha_calificacion':

                    $stmt5 = "UPDATE calificacion
                    SET fecha_calificacion='$fecha_completa' WHERE id_calificacion=$id_calificacion";
                    $resultado5 = mysqli_query($mysqli, $stmt5);
                    break;
                                                    
                default:

                    header('Location: principal.php?error=true');
                    exit;
            }
            break;
        case 'Borrar':

            $stmt7 = "DELETE FROM calificacion
            WHERE id_calificacion = $id_calificacion";
            $resultado7 = mysqli_query($mysqli, $stmt7);

            break;
        default:

            header('Location: principal.php?error=true');
            exit;

    }

} else {
    header('Location: principal.php?error=true');
    exit;
}

header('Location: principal.php');
exit;