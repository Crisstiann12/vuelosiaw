<!DOCTYPE html>
<html lang="es">

<head>
    <title>Perfil del Usuario</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        body {
            background-image: url('img/terminal.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        .user-details {
            margin-bottom: 20px;
        }

        .user-details label {
            font-weight: bold;
        }

        .user-details div {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .btn-group {
            text-align: center;
            margin-top: 20px;
        }

        .btn-group button {
            padding: 8px 20px;
            margin: 0 5px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }

        .btn-group button.delete {
            background-color: #dc3545;
            color: #fff;
        }

        .btn-group button.save {
            background-color: #28a745;
            color: #fff;
        }
    </style>
</head>

<?php
session_start();
include "cabecera_admin.php";

$dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
$dbuser = "root";
$dbpass = "root123456789";
$db = "VUELOS";

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);
if ($mysqli->connect_errno) {
    die("La conexión a la base de datos falló: " . $mysqli->connect_error);
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) { // === (Igual y del mismo tipo)
    $stmt = $mysqli->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'delete') {
        $stmt = $mysqli->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $_POST['id']);
        $stmt->execute();
        header("Location: gestion_usuarios.php");
        exit();
    } elseif ($_POST['action'] === 'save') {

        $stmt = $mysqli->prepare("SELECT id FROM usuarios WHERE usuario = ? AND id != ?");
        $stmt->bind_param("si", $_POST['usuario'], $_POST['id']);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $message = "El usuario ya existe";
        } else {

            $admin = ($_POST['admin'] === 'SI') ? 'SI' : 'NO';
            $stmt = $mysqli->prepare("UPDATE usuarios SET nombre = ?, apellidos = ?, usuario = ?, admin = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $_POST['nombre'], $_POST['apellidos'], $_POST['usuario'], $admin, $_POST['id']);
            $stmt->execute();
        }
    }
}
?>

<body>
    <div class="container">
        <h1>Perfil del Usuario</h1>
        <?php if ($message): ?>
            <div class="alert alert-danger">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <div class="user-details">
            <label for="nombre">Nombre:</label>
            <div><?php echo $user['nombre']; ?></div>
        </div>
        <div class="user-details">
            <label for="apellidos">Apellidos:</label>
            <div><?php echo $user['apellidos']; ?></div>
        </div>
        <div class="user-details">
            <label for="usuario">Usuario:</label>
            <div><?php echo $user['usuario']; ?></div>
        </div>
        <div class="user-details">
            <label for="admin">Permisos de Administración:</label>
            <div>
                <form action="gestion_usuario_individual.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                    <input type="text" name="nombre" value="<?php echo $user['nombre']; ?>" placeholder="Nombre">
                    <input type="text" name="apellidos" value="<?php echo $user['apellidos']; ?>" placeholder="Apellidos">
                    <input type="text" name="usuario" value="<?php echo $user['usuario']; ?>" placeholder="Usuario">
                    <select name="admin">
                        <option value="NO" <?php if ($user['admin'] == 'NO') echo "selected"; ?>>NO</option>
                        <option value="SI" <?php if ($user['admin'] == 'SI') echo "selected"; ?>>SI</option>
                    </select>
                    <input type="hidden" name="action" value="save">
                    <button type="submit" class="save">Guardar</button>
                </form>
            </div>
        </div>
        <div class="btn-group">
            <form action="gestion_usuario_individual.php" method="post">
                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="delete">Eliminar</button>
            </form>
            <form action="gestion_usuarios.php" method="post">
                <button type="submit" class="volver">Volver</button>
            </form>
        </div>
    </div>
</body>

</html>
