CREATE DATABASE VUELOS;
USE VUELOS;

-- Crear la tabla de aeropuertos con el nombre de la ciudad
CREATE TABLE aeropuertos (
    codigo VARCHAR(3) PRIMARY KEY,
    ciudad VARCHAR(100)
);

-- Insertar datos para 10 aeropuertos españoles
INSERT INTO aeropuertos (codigo, ciudad) VALUES
('MAD', 'Madrid'),
('BCN', 'Barcelona'),
('AGP', 'Málaga'),
('VLC', 'Valencia'),
('SVQ', 'Sevilla'),
('LPA', 'Las Palmas de Gran Canaria'),
('PMI', 'Palma de Mallorca'),
('LCG', 'A Coruña'),
('TFN', 'Santa Cruz de Tenerife'),
('IBZ', 'Ibiza');

-- Puedes agregar más inserciones según sea necesario

-- Crear la tabla de usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    apellidos VARCHAR(50),
    usuario VARCHAR(20) UNIQUE,
    contrasena VARCHAR(255)
);

-- Insertar datos de ejemplo para 10 usuarios
INSERT INTO usuarios (nombre, apellidos, usuario, contrasena) VALUES
('Juan', 'Gómez Pérez', 'juanito123', 'clave123'),
('María', 'López García', 'marialo', 'password456'),
('Carlos', 'Martínez Ruiz', 'carlitos', 'secreto789'),
('Ana', 'Sánchez Rodríguez', 'anita', 'contraseña321'),
('Pedro', 'Fernández González', 'pedrito', 'securepass'),
('Laura', 'Díaz Martín', 'lauritad', 'password123'),
('Sergio', 'Gutiérrez López', 'sergio89', 'mysecret'),
('Elena', 'Romero Torres', 'elena_r', 'clave456'),
('Daniel', 'García Serrano', 'dan_27', 'danielpass'),
('Natalia', 'Hernández Ruiz', 'natah', 'mypassword');

-- Puedes agregar más inserciones según sea necesario

-- Crear la tabla de vuelos
-- Crear la tabla de vuelos con el código de vuelo
CREATE TABLE vuelos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo_aeropuerto_origen VARCHAR(3),
    codigo_aeropuerto_destino VARCHAR(3),
    fecha_salida DATE,
    hora_salida TIME,
    fecha_llegada DATE,
    hora_llegada TIME,
    plazas_libres INT,
    precio DECIMAL(10, 2),
    CONSTRAINT fk_aeropuerto_origen FOREIGN KEY (codigo_aeropuerto_origen) REFERENCES aeropuertos(codigo),
    CONSTRAINT fk_aeropuerto_destino FOREIGN KEY (codigo_aeropuerto_destino) REFERENCES aeropuertos(codigo)
);


INSERT INTO vuelos (codigo_aeropuerto_origen, codigo_aeropuerto_destino, fecha_salida, hora_salida, fecha_llegada, hora_llegada, plazas_libres, precio) VALUES
('MAD', 'BCN', '2024-05-01', '08:00:00', '2024-05-01', '10:00:00', 100, 150.00),
('BCN', 'MAD', '2024-05-01', '12:00:00', '2024-05-01', '14:00:00', 120, 130.50),
('AGP', 'VLC', '2024-05-01', '10:30:00', '2024-05-01', '12:30:00', 80, 180.75),
('VLC', 'MAD', '2024-05-02', '09:45:00', '2024-05-02', '11:45:00', 90, 160.25),
('BCN', 'AGP', '2024-05-02', '14:30:00', '2024-05-02', '16:30:00', 110, 145.00),
('SVQ', 'LPA', '2024-05-02', '11:15:00', '2024-05-02', '13:15:00', 75, 200.00),
('LPA', 'SVQ', '2024-05-03', '13:00:00', '2024-05-03', '15:00:00', 95, 175.50),
('PMI', 'LCG', '2024-05-03', '15:30:00', '2024-05-03', '17:30:00', 85, 190.25),
('LCG', 'MAD', '2024-05-03', '18:45:00', '2024-05-03', '20:45:00', 100, 155.75),
('TFN', 'IBZ', '2024-05-04', '16:00:00', '2024-05-04', '18:00:00', 120, 165.00),
('MAD', 'SVQ', '2024-05-04', '10:00:00', '2024-05-04', '12:00:00', 80, 175.25),
('BCN', 'PMI', '2024-05-04', '14:45:00', '2024-05-04', '16:45:00', 110, 140.50),
('AGP', 'TFN', '2024-05-05', '12:30:00', '2024-05-05', '14:30:00', 95, 185.00),
('VLC', 'LCG', '2024-05-05', '09:15:00', '2024-05-05', '11:15:00', 70, 195.75),
('BCN', 'IBZ', '2024-05-05', '17:30:00', '2024-05-05', '19:30:00', 105, 160.25),
('SVQ', 'MAD', '2024-05-01', '08:00:00', '2024-05-01', '10:00:00', 90, 165.50),
('MAD', 'BCN', '2024-05-01', '12:00:00', '2024-05-01', '14:00:00', 110, 140.00),
('AGP', 'VLC', '2024-05-01', '10:30:00', '2024-05-01', '12:30:00', 80, 175.25),
('VLC', 'MAD', '2024-05-02', '09:45:00', '2024-05-02', '11:45:00', 100, 155.00),
('BCN', 'AGP', '2024-05-02', '14:30:00', '2024-05-02', '16:30:00', 120, 135.50),
('SVQ', 'LPA', '2024-05-02', '11:15:00', '2024-05-02', '13:15:00', 70, 190.00),
('LPA', 'SVQ', '2024-05-03', '13:00:00', '2024-05-03', '15:00:00', 80, 170.75),
('PMI', 'LCG', '2024-05-03', '15:30:00', '2024-05-03', '17:30:00', 110, 185.25),
('LCG', 'MAD', '2024-05-03', '18:45:00', '2024-05-03', '20:45:00', 95, 150.50),
('TFN', 'IBZ', '2024-05-04', '16:00:00', '2024-05-04', '18:00:00', 105, 160.00),
('MAD', 'SVQ', '2024-05-04', '10:00:00', '2024-05-04', '12:00:00', 80, 170.25),
('BCN', 'PMI', '2024-05-04', '14:45:00', '2024-05-04', '16:45:00', 90, 135.75),
('AGP', 'TFN', '2024-05-05', '12:30:00', '2024-05-05', '14:30:00', 100, 180.00),
('VLC', 'LCG', '2024-05-05', '09:15:00', '2024-05-05', '11:15:00', 75, 190.75);



CREATE TABLE compras (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_vuelo INT,  -- Cambiado a id_vuelo en lugar de codigo_vuelo
    numero_plazas INT,
    precio_total DECIMAL(10, 2),
    CONSTRAINT fk_usuario_compra FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
    CONSTRAINT fk_vuelo_compra FOREIGN KEY (id_vuelo) REFERENCES vuelos(id)  -- Cambiado a id_vuelo en lugar de codigo_vuelo
);
-- Insertar datos de ejemplo en la tabla de compras
INSERT INTO compras (id_usuario, id_vuelo, numero_plazas, precio_total) VALUES
(1, 1, 2, 300.00),   
(2, 2, 1, 130.50),   
(3, 3, 3, 542.25),   
(4, 4, 2, 320.50),   
(5, 5, 1, 145.00);
