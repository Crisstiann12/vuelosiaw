<?php include "cabecera.php"; ?>
<div class="tm-section tm-bg-img" id="tm-section-1">
    <div class="tm-bg-white ie-container-width-fix-2">
        <div class="container ie-h-align-center-fix">
            <div class="row">
                <div class="col-xs-12 ml-auto mr-auto ie-container-width-fix">

                    <h2 style="text-align:center;">Escoge tu viaje</h2>

                    <form action="seleccionarVuelo.php" method="post" id="formIndex" class="tm-search-form tm-section-pad-2">

                    <?php 
                    
                    if(isset($_GET['error']) && $_GET['error'] == true) {

                        echo "<p style='color: red;'>Selecciona todas las opciones</p>";

                    }
                    
                    ?>
                        <div class="form-row tm-search-form-row">
                            <div class="form-group tm-form-element tm-form-element-100">
                                <i class="fa fa-map-marker fa-2x tm-form-element-icon"></i>
                                <select name="ciudadOrigen" class="form-control tm-select" id="originCity">
                                    <option value='selecciona'>Selecciona origen</option>
                                    <option value='Madrid'>Madrid</option>
                                    <option value='A Coruña'>A Coruña</option>
                                    <option value='Lanzarote'>Lanzarote</option>
                                    <option value='Gandía'>Gandía</option>
                                    <option value='Asturias'>Asturias</option>
                                    <option value='Barcelona'>Barcelona</option>
                                    <option value='Valencia'>Valencia</option>
                                    <option value='Ibiza'>Ibiza</option>
                                </select>
                            </div>
                            <div class="form-group tm-form-element tm-form-element-100">
                                <i class="fa fa-map-marker fa-2x tm-form-element-icon"></i>
                                <select name="ciudadDestino" class="form-control tm-select" id="originCity">
                                    <option value='selecciona'>Selecciona destino</option>

                                    <option value='Madrid'>Madrid</option>
                                    <option value='A Coruña'>A Coruña</option>
                                    <option value='Lanzarote'>Lanzarote</option>
                                    <option value='Gandía'>Gandía</option>
                                    <option value='Asturias'>Asturias</option>
                                    <option value='Barcelona'>Barcelona</option>
                                    <option value='Valencia'>Valencia</option>
                                    <option value='Ibiza'>Ibiza</option>
                                </select>
                            </div>
                        </div>


                        <div class="form-row tm-search-form-row">
                            <div class="form-group tm-form-element tm-form-element-2">
                                <input type="number" min="0" value="0" name="selectAdultos" id="selectAdultos" class="form-control" placeholder="Numero de adultos">

                                <i class="fa fa-2x fa-user tm-form-element-icon"></i>
                            </div>
                            <div class="form-group tm-form-element tm-form-element-2">
                                <input type="number" min="0" value="0" name="selectNinos" id="selectNinos" class="form-control" placeholder="Numero de niños">

                                <i class="fa fa-user tm-form-element-icon tm-form-element-icon-small"></i>
                            </div>

                            <div class="form-group tm-form-element tm-form-element-2">
                                <button type="submit" class="btn btn-primary tm-btn-search"> Comprobar disponibilidad</button>

                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="tm-section-2">
    <div class="container">
        <div class="row">
            <div class="col text-center">
                <h2 class="tm-section-title">Elige una ruta, no una rutina</h2>
                <p class="tm-color-white tm-section-subtitle">Los mejores viajes responden a preguntas que antes ni te hacias</p>
                <a href="#" class="tm-color-white tm-btn-white-bordered">Subscribe Newletters</a>
            </div>
        </div>
    </div>
</div>


<!-- load JS files -->
<script src="js/jquery-1.11.3.min.js"></script> <!-- jQuery (https://jquery.com/download/) -->
<script src="js/popper.min.js"></script> <!-- https://popper.js.org/ -->
<script src="js/bootstrap.min.js"></script> <!-- https://getbootstrap.com/ -->
<script src="js/datepicker.min.js"></script> <!-- https://github.com/qodesmith/datepicker -->
<script src="js/jquery.singlePageNav.min.js"></script> <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
<script src="slick/slick.min.js"></script> <!-- http://kenwheeler.github.io/slick/ -->


</body>

</html>