<?php include "cabecera.php"; ?>

<div class="tm-section tm-bg-img" id="tm-section-1">
    <div class="tm-bg-white ie-container-width-fix-2">
        <div class="container ie-h-align-center-fix">
            <div class="row">
                <div class="col-xs-12 ml-auto mr-auto ie-container-width-fix">


                    <form action="procesar_login.php" method="post" class="tm-search-form tm-section-pad-2" id="formPagar">

                        <div class="form-group">
                            <label class="col-form-label" for="inputNombre">Usuario</label>
                            <input type="text" name="nombreUsuario" class="form-control"  id="inputNombre">
                        </div>


                        <div class="form-group">
                            <label class="col-form-label" for="inputPassword">Contraseña</label>
                            <input type="password" name="password" class="form-control"  id="inputPassword">
                        </div>
                        <?php 
                    
                        if(isset($_GET['error']) && $_GET['error'] == 'iniciosession') {

                        echo "<p style='color: red;'>Inicia Sesión para Continuar</p>";

                        } elseif (isset($_GET['error']) && $_GET['error'] == 'failsesion') {

                        echo "<p style='color: red;'>Usuario o Contraseña Incorrectos</p>";

                        }
                        ?>

                        <button type=" submit" class="btn btn-primary tm-btn-search"> Log In</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>




</body>

</html>