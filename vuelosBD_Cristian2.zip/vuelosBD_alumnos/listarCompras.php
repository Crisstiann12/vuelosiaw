<!DOCTYPE html>
<html lang="es">

<head>
    <title>LISTAR COMPRAS</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        /* Your existing styles remain here */

        .contenedor-tabla {
            margin: 20px;
        }

        table {
            margin: auto;
            width: 80%;
        }

        th,
        td {
            padding: 12px;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php include "cabecera.php"; 

    if (!$_SESSION['logueado']) {

        header("Location: login.php?error=iniciosession");
    }

    ?>
    <div class="tm-section tm-bg-img" id="tm-section-1">
        <div class="tm-bg-white ie-container-width-fix-2">
            <div class="container ie-h-align-center-fix">
                <div class="row">
                    <div class="col-xl-8 ml-auto mr-auto ie-container-width-fix">
                        <?php
                        if (isset($_SESSION['logueado']) && $_SESSION['logueado'] == true) {

                            $iduser = $_SESSION['iduser'];

                            $dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
                            $dbuser = "root";
                            $dbpass = "root123456789";
                            $db = "VUELOS";

                            $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);

                            if ($mysqli->connect_errno) {
        
                                die("La conexión a la base de datos falló: " . $mysqli->connect_error);
                            }

                            $stmt = $mysqli->query("SELECT * FROM compras WHERE id_usuario = $iduser");
                            ?>
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>ID Usuario</th>
                                        <th>ID Vuelo</th>
                                        <th>Número de Plazas</th>
                                        <th>Precio Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while ($fila = $stmt->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $fila['id'] . "</td>
                                              <td>" . $fila['id_usuario'] . "</td>
                                              <td>" . $fila['id_vuelo'] . "</td>
                                              <td>" . $fila['numero_plazas'] . "</td>
                                              <td>" . $fila['precio_total'] . "</td>";
                                        echo "</tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        <?php
                        } else {
                            header('Location: login.php?error=iniciosession');
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
