<?php include "cabecera.php";

if (isset($_SESSION['logueado']) && ($_SESSION['logueado']) == true) {
    if (
        !isset($_POST['ciudadOrigen']) ||
        !isset($_POST['ciudadDestino']) ||
        empty($_POST['selectAdultos']) ||
        $_POST['ciudadOrigen'] == "selecciona" ||
        $_POST['ciudadDestino'] == "selecciona" ||
        $_POST['ciudadOrigen'] == $_POST['ciudadDestino']
    ) {
        header("Location: index.php?error=true");
    }

    $origen = $_POST['ciudadOrigen'];
    $destino = $_POST['ciudadDestino'];
    
} else {
    header('Location: login.php?error=iniciosession');
}
?>


<div class="tm-section tm-bg-img" id="tm-section-1">
    <div class="tm-bg-white ie-container-width-fix-2">
        <div class="container ie-h-align-center-fix">
            <div class="row">
                <div class="col-xs-12 ml-auto mr-auto ie-container-width-fix">

                    <br>
                    <br>
                    <form action="comprarVuelo.php" method="post" id="formIndex" class="tm-search-form tm-section-pad-2">

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Vuelo</th>
                                    <th>Aeropuerto de Origen</th>
                                    <th>Aeropuerto de Destino</th>
                                    <th>Plazas</th>
                                    <th>Fecha de Salida</th>
                                    <th>Fecha de Regreso</th>
                                    <th>Precio</th>
                                    <th>Selecciona</th>

                                </tr>
                                <?php

                                

                                $_SESSION['numero_adultos'] = $_POST['selectAdultos'];

                                $_SESSION['numero_ninos'] = $_POST['selectNinos'];

                                $dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
                                $dbuser = "root";
                                $dbpass = "root123456789";
                                $db = "VUELOS";

                                $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);

                                if ($mysqli->connect_errno) {
                                    die("La conexión a la base de datos falló: " . $mysqli->connect_error);
                                }

                                $stmt = $mysqli->query("SELECT v.id,
                                v.codigo_aeropuerto_origen,
                                o.ciudad AS ciudad_origen,
                                v.codigo_aeropuerto_destino,
                                d.ciudad AS ciudad_destino,
                                v.fecha_salida,
                                v.hora_salida,
                                v.fecha_llegada,
                                v.hora_llegada,
                                v.plazas_libres,
                                v.precio
                                
                                    FROM vuelos v
                                    JOIN aeropuertos o ON v.codigo_aeropuerto_origen = o.codigo
                                    JOIN aeropuertos d ON v.codigo_aeropuerto_destino = d.codigo
                                    WHERE o.ciudad = '$origen' AND d.ciudad = '$destino';
                                ");

                                if ($stmt) {
                                    $hayVuelos = false;

                                    while ($fila = $stmt->fetch_assoc()) {
                                        $hayVuelos = true;
                                        echo "<tr>";
                                        echo "<td>" . $fila['id'] . "</td>
                                        <td>" . $fila['ciudad_origen'] . "</td>
                                        <td>" . $fila['ciudad_destino'] . "</td>
                                        <td>" . $fila['plazas_libres'] . "</td>
                                        <td>" . $fila['fecha_salida'] . "</td>
                                        <td>" . $fila['fecha_llegada'] . "</td>
                                        <td>" . $fila['precio'] . "</td>";
                                        $concadenarvalores = implode(',', $fila);
                                        echo "<td>
                                    <div style='text-align: center;'>
                                    <input type='radio' name='selecciona' value='{$concadenarvalores}'>
                                    </div>
                                    </td></tr>";
                                    }

                                    $stmt->close();
                                    $mysqli->close();

                                    if (!$hayVuelos) {
                                        echo "<div style='text-align: center;'>
                                    <h2 style='color: red;'>No hay vuelos disponibles</h2>
                                    </div>";
                                    } else {
                                        echo "</tbody></table>";
                                        echo "<button type='submit' class='btn btn-primary tm-btn-search'>Seleccionar vuelo</button>";
                                    }
                                }
                                ?>
                    </form>

                    <?php
                    if (!$hayVuelos) {
                        echo '<form action="index.php" method="post" id="formIndex" class="tm-search-form tm-section-pad-2">';
                        echo '<button type="submit" class="btn btn-primary tm-btn-search">Volver Atrás</button>';
                    }
                    ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- load JS files -->
<script src="js/jquery-1.11.3.min.js"></script> <!-- jQuery (https://jquery.com/download/) -->
<script src="js/popper.min.js"></script> <!-- https://popper.js.org/ -->
<script src="js/bootstrap.min.js"></script> <!-- https://getbootstrap.com/ -->
<script src="js/datepicker.min.js"></script> <!-- https://github.com/qodesmith/datepicker -->
<script src="js/jquery.singlePageNav.min.js"></script> <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
<script src="slick/slick.min.js"></script> <!-- http://kenwheeler.github.io/slick/ -->


</body>

</html>