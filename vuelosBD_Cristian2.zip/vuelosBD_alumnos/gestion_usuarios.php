<!DOCTYPE html>
<html lang="es">

<head>
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        body {
            background-image: url('img/terminal.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }

        .tm-section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .tm-bg-img {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            width: 80%;
        }

        .tm-section h2 {
            width: 100%;
            text-align: center;
            margin: 10px 0;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php include "cabecera.php"; 
    
    if (!$_SESSION['admin']) {
        header("Location: index.php");
    }
    
    ?>
    <div class="tm-section">
        <div class="tm-bg-img">
            <div style="width: 45%;">
                <h2>Gestión de Usuarios</h2>
                <hr>
            </div>
        </div>
    </div>
</body>

</html>
