<?php

if (isset($_SESSION['logueado']) && $_SESSION['logueado'] == true) {

    header("Location: index.php");

}

$dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
$dbuser = "root";
$dbpass = "root123456789";
$database = "VUELOS";

// Crear conexión a la base de datos principal
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $database);

if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_errno);
    exit();
}

if (isset($_POST['nombreUsuario']) && isset($_POST['password'])) {
    $usuario = $_POST['nombreUsuario'];
    $password = $_POST['password'];

    $query = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND contrasena = '$password'";
    
    $stmt = $mysqli->query($query);

    if ($stmt) {
        $fila = $stmt->fetch_assoc();

        if ($usuario == $fila['usuario'] && $password == $fila['contrasena']) {
            // Iniciar sesión y redirigir a la página principal
            session_start();
            $_SESSION['usuario'] = $fila['usuario'];
            $_SESSION['iduser'] = $fila['id'];
            $_SESSION['logueado'] = true;

            // Verificar si el usuario es administrador
            if ($fila['admin'] == 'S') {
                $_SESSION['admin'] = true;
            }
            
            header("Location: index.php");
            exit();
        }
    }
}

// Redirigir a la página de login en caso de credenciales incorrectas o errores
header("Location: login.php?error=failsesion");
exit();
?>
