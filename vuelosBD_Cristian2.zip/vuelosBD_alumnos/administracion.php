<!DOCTYPE html>
<html lang="es">

<head>
    <title>Área de Administración</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <style>
        body {
            background-image: url('img/terminal.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }

        .tm-section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .tm-bg-img {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
            width: 80%;
        }

        .tm-section h2 {
            width: 100%;
            text-align: center;
            margin: 10px 0;
            cursor: pointer; /* Cambia el cursor al pasar sobre los títulos */
        }
    </style>
</head>

<body>
    <?php include "cabecera.php"; 
    
    if (!$_SESSION['admin']) {
        header("Location: index.php");
    }
    
    ?>
    <div class="tm-section">
        <div class="tm-bg-img">
            <div style="width: 45%;">
                <a href="gestion_usuarios.php"><h2>Gestión de Usuarios</h2></a>
                <hr>
            </div>
            <div style="width: 45%;">
                <a href="gestion_vuelos.php"><h2>Gestión de Vuelos</h2></a>
                <hr>
            </div>
            <div style="width: 45%;">
                <a href="gestion_compras.php"><h2>Gestión de Compras</h2></a>
                <hr>
            </div>
            <div style="width: 45%;">
                <a href="gestion_aeropuertos.php"><h2>Gestión de Aeropuertos</h2></a>
                <hr>
            </div>
        </div>
    </div>
</body>

</html>
