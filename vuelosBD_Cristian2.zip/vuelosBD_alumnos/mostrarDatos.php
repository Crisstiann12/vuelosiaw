<?php include "cabecera.php"; ?>



<?php

if (isset($_SESSION['logueado']) && ($_SESSION['logueado']) == true) {
    $colores = ['#dfedf6', '#bfdbed', '#9fc9e4', '#7fb7db', '#5fa5d2', '#3f93c9', '#1f81c0'];


    $color_defecto = 'CornflowerBlue';

    if (
        !isset($_POST['politica-cancelacion']) ||
        !isset($_POST['nombreUsuario']) ||
        !isset($_POST['apellidoUsuario']) ||
        !isset($_POST['tarjetaUsuario']) ||
        $_POST['politica-cancelacion'] == "Selecciona una tarifa" ||
        $_POST['tarjetaUsuario'] == ""
    ) {

        header("Location: comprarVuelo.php?error=true");
    }

    $user = $_SESSION['usuario'];
    $nombreUsuario = $_POST['nombreUsuario'];
    $apellido = $_POST['apellidoUsuario'];
    $politica_cancelacion = $_POST['politica-cancelacion'];
    $tarjetaUsuario = $_POST['tarjetaUsuario'];
    $id_vuelo = $_SESSION['id'];
    $id_user = $_SESSION['iduser'];
    $ciudad_origen = $_SESSION['ciudad_origen'];
    $ciudad_destino = $_SESSION['ciudad_destino'];
    $plazas_libres = $_SESSION['plazas_libres'];
    $fecha_salida = $_SESSION['fecha_salida'];
    $fecha_llegada = $_SESSION['fecha_llegada'];
    $precio = $_SESSION['precio'];
    $numero_Adultos = $_SESSION['numero_adultos'];
    $numero_ninos = $_SESSION['numero_ninos'];

    $pasajeros_totales = $numero_Adultos + $numero_ninos;

    $precio_total_compra = $pasajeros_totales * $precio;


    $plazas_libresbd = $plazas_libres - $pasajeros_totales;


    $dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
    $dbuser = "root";
    $dbpass = "root123456789";
    $db = "VUELOS";

    $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);

    if ($mysqli->connect_errno) {
        die("La conexión a la base de datos falló: " . $mysqli->connect_error);
    }

    $stmt = "INSERT INTO compras (id_usuario,id_vuelo,numero_plazas,precio_total) 
                        VALUES ($id_user,$id_vuelo, $pasajeros_totales, '$precio_total_compra');";
    $resultado = mysqli_query($mysqli, $stmt);



    $stmt2 = "UPDATE vuelos 
            SET plazas_libres = $plazas_libresbd
            WHERE id = $id_vuelo";
    $resultado2 = mysqli_query($mysqli, $stmt2);
} else {
    header('Location: login.php?error=iniciosession');
}

?>


<div class="tm-section tm-bg-img" id="tm-section-1">
    <div class="tm-bg ie-container-width-fix-2">
        <div class="container ie-h-align-center-fix">
            <div class="row">
                <div class="col-xl-8 ml-auto mr-auto ie-container-width-fix">

                    <?php
                    print "<div class='tm-section-2'  style='background-color:" . $color_defecto . ";'>";
                    ?>
                    <div class="container">
                        <div class="row">
                            <div class="col text-center">
                                <?php
                                print "<h2 class='tm-section-title'><h3> Felicidades $user por comprar el vuelo, datos de la reserva:  </h3><br></h2>
                            <p class='tm-color-white tm-section-subtitle'>Nombre: $nombreUsuario </p>
                            <p class='tm-color-white tm-section-subtitle'>Apellidos: $apellido</p>
                            <p class='tm-color-white tm-section-subtitle'>Tarifa: $politica_cancelacion</p>
                            <p class='tm-color-white tm-section-subtitle'>Fecha check in : $fecha_salida</p>
                            <p class='tm-color-white tm-section-subtitle'>Fecha check out: $fecha_llegada</p>
                            <p class='tm-color-white tm-section-subtitle'>Ciudad de origen: $ciudad_origen</p>
                            <p class='tm-color-white tm-section-subtitle'>Ciudad de destino: $ciudad_destino </p>
                            <p class='tm-color-white tm-section-subtitle'>Número de adultos: $numero_Adultos</p>
                            <p class='tm-color-white tm-section-subtitle'>Número de niños: $numero_ninos</p>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- load JS files -->
                <script src="js/jquery-1.11.3.min.js"></script> <!-- jQuery (https://jquery.com/download/) -->
                <script src="js/popper.min.js"></script> <!-- https://popper.js.org/ -->
                <script src="js/bootstrap.min.js"></script> <!-- https://getbootstrap.com/ -->
                <script src="js/datepicker.min.js"></script> <!-- https://github.com/qodesmith/datepicker -->
                <script src="js/jquery.singlePageNav.min.js"></script> <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
                <script src="slick/slick.min.js"></script> <!-- http://kenwheeler.github.io/slick/ -->


                </body>

                </html>