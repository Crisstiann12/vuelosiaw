<?php

if (isset($_POST['Nombre']) && isset($_POST['Apellidos']) && isset($_POST['Usuario']) && isset($_POST['password'])) {

    $dbhost = "tfgv1.cr2ikka8s0yb.us-east-1.rds.amazonaws.com";
    $dbuser = "root";
    $dbpass = "root123456789";
    $db = "VUELOS";

    $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $db);

    if ($mysqli->connect_errno) {
        die("La conexión a la base de datos falló: " . $mysqli->connect_error);
    }

    if (empty($_POST['Nombre']) || empty($_POST['Apellidos']) || empty($_POST['Usuario']) || empty($_POST['password'])) {

        header("Location: registro.php?error1=failsesion");
        exit();
    }

    // Nos protegemos ante un ataque de SQL Injection
    $nombre = $mysqli->real_escape_string($_POST['Nombre']);
    $apellidos = $mysqli->real_escape_string($_POST['Apellidos']);
    $usuario = $mysqli->real_escape_string($_POST['Usuario']);
    $contrasena = $mysqli->real_escape_string($_POST['password']);

    // Verificamos si hubo errores al escapar las variables
    if (!$nombre || !$apellidos || !$usuario || !$contrasena) {
        header("Location: registro.php?error3=errorregistro");
        exit();
    }

    // Consulta para verificar si el usuario YA EXISTE
    $query = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $stmt = $mysqli->query($query);

    if ($stmt) {
        $fila = $stmt->fetch_assoc();

        if ($usuario == $fila['usuario']) {
            header("Location: registro.php?error2=usrexistente");
            exit();
        } else {
        $stmt2 = "INSERT INTO usuarios (nombre, apellidos, usuario, contrasena) 
                            VALUES ('$nombre', '$apellidos', '$usuario', '$contrasena')";
        $stmt2 = mysqli_query($mysqli, $stmt2);

        // Cerrar la conexión
        $mysqli->close();

        header("Location: index.php");
        exit();
        }
    }

} else {
    header("Location: registro.php?error1=failsesion");
    exit();
}

?>